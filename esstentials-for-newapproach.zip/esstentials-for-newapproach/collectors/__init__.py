"""Collectors fetch raw facts from a data source (live Compute API or the
offline snapshot) and hand them to generators. They do no interpretation."""
