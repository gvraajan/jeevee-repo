"""Generators turn collected facts into validated, serialisable artifacts.
Each generator returns a Pydantic model, guaranteeing schema-valid JSON."""
