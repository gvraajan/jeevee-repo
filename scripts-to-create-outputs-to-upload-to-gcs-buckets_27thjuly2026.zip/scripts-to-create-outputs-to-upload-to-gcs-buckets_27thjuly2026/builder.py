"""GCP Storage Advisor -- Knowledge Builder entrypoint.

Orchestrates collectors and generators to produce the three JSON artifacts that
Cloud Run consumes:

    output/catalog.json     -- the knowledge base (API skeleton + curated overlay)
    output/rules.json       -- data-driven recommendation rules
    output/questions.json   -- the questionnaire

Usage
-----
    python builder.py                               # offline mode
    python builder.py --live --project MYPROJ           # live Compute API mode
    python builder.py --only catalog                    # single artifact
    python builder.py --upload --bucket my-bucket       # build + upload to GCS

Review output/ first, then either upload manually or use --upload.
"""
from __future__ import annotations

import argparse
import json
import logging
import sys
from pathlib import Path

import config
from collectors.compatibility import CompatibilityIndex
from collectors.compute import ComputeClient
from collectors.disks import DiskCollector
from collectors.documentation import DocumentationCollector
from collectors.machine_types import MachineTypeCollector
from collectors.regions import RegionCollector
from generators.catalog import CatalogGenerator
from generators.questions import QuestionsGenerator
from generators.rules import RulesGenerator
from models import Metadata


class KnowledgeBuilder:
    def __init__(self, settings: config.BuilderSettings, log: logging.Logger) -> None:
        settings.validate()
        self.settings = settings
        self.log = log
        self.client = ComputeClient(settings)
        overlay = DocumentationCollector().load()
        self.compat = CompatibilityIndex(overlay)

    # ------------------------------------------------------------------ #
    def _metadata(self) -> Metadata:
        return Metadata(
            knowledge_version=config.KNOWLEDGE_VERSION,
            builder_version=config.BUILDER_VERSION,
            generated_at=config.utc_now_iso(),
            documentation_as_of=config.DOCUMENTATION_AS_OF,
            mode=self.settings.mode,  # type: ignore[arg-type]
            data_sources=[
                self.client.data_source_label,
                f"curated overlay: {config.COMPATIBILITY_YAML.name}",
            ],
        )

    def _write(self, model, path) -> None:
        config.OUTPUT_DIR.mkdir(parents=True, exist_ok=True)
        payload = model.model_dump(by_alias=True, exclude_none=False)
        with path.open("w", encoding="utf-8") as fh:
            json.dump(payload, fh, indent=2, ensure_ascii=False)
        self.log.info("Wrote %s (%d bytes)", path, path.stat().st_size)

    # ------------------------------------------------------------------ #
    def build_catalog(self) -> None:
        self.log.info("--- Building catalog.json ---")
        regions = RegionCollector(self.client).collect()
        zone_names = [z["name"] for z in regions["zones"]]

        machine_types = MachineTypeCollector(self.client).collect(zone_names)
        disk_types = DiskCollector(self.client).collect(zone_names)

        catalog = CatalogGenerator(self.compat).build(
            regions_raw=regions["regions"],
            zones_raw=regions["zones"],
            machine_types_raw=machine_types,
            disk_types_raw=disk_types,
            metadata=self._metadata(),
        )
        self._write(catalog, config.CATALOG_PATH)

    def build_rules(self) -> None:
        self.log.info("--- Building rules.json ---")
        rules = RulesGenerator().build(self._metadata())
        self._write(rules, config.RULES_PATH)

    def build_questions(self) -> None:
        self.log.info("--- Building questions.json ---")
        questions = QuestionsGenerator().build(self._metadata())
        self._write(questions, config.QUESTIONS_PATH)

    def build_all(self, only: str | None) -> None:
        targets = {
            "catalog": self.build_catalog,
            "rules": self.build_rules,
            "questions": self.build_questions,
        }
        chosen = [targets[only]] if only else list(targets.values())
        for fn in chosen:
            fn()
        self.log.info("Done. Artifacts in %s", config.OUTPUT_DIR)

    # ------------------------------------------------------------------ #
    # GCS Upload
    # ------------------------------------------------------------------ #
    def upload(self, bucket_name: str) -> None:
        try:
            from google.cloud import storage  # noqa: PLC0415
        except ImportError as exc:
            raise RuntimeError(
                "GCS upload needs google-cloud-storage. "
                "Install it: pip install google-cloud-storage"
            ) from exc

        client = storage.Client()
        bucket = client.bucket(bucket_name)
        prefix = f"knowledge/{config.KNOWLEDGE_VERSION}"

        artifacts: list[tuple[Path, str]] = [
            (config.CATALOG_PATH, f"{prefix}/catalog.json"),
            (config.RULES_PATH, f"{prefix}/rules.json"),
            (config.QUESTIONS_PATH, f"{prefix}/questions.json"),
        ]

        for local_path, blob_name in artifacts:
            if not local_path.exists():
                self.log.warning("Skipping %s (not found)", local_path)
                continue
            blob = bucket.blob(blob_name)
            blob.upload_from_filename(str(local_path))
            self.log.info(
                "Uploaded %s -> gs://%s/%s", local_path.name, bucket_name, blob_name,
            )

        # Also upload a "latest" copy for convenient reference.
        for local_path, blob_name in artifacts:
            latest_name = blob_name.replace(f"{prefix}/", "knowledge/latest/")
            blob = bucket.blob(latest_name)
            blob.upload_from_filename(str(local_path))
        self.log.info("Uploaded latest/ copies to gs://%s/knowledge/latest/", bucket_name)


def parse_args(argv: list[str]) -> argparse.Namespace:
    p = argparse.ArgumentParser(description="GCP Storage Advisor knowledge builder")
    p.add_argument("--live", action="store_true",
                   help="Use the live Compute API instead of the offline snapshot.")
    p.add_argument("--project", help="GCP project id (required with --live).")
    p.add_argument("--regions", nargs="*", default=[],
                   help="Limit live collection to these regions.")
    p.add_argument("--only", choices=["catalog", "rules", "questions"],
                   help="Build only one artifact.")
    p.add_argument("--upload", action="store_true",
                   help="Upload artifacts to GCS after building.")
    p.add_argument("--bucket", help="GCS bucket name (required with --upload).")
    p.add_argument("--log-level", default="INFO")
    return p.parse_args(argv)


def main(argv: list[str]) -> int:
    args = parse_args(argv)
    log = config.configure_logging(args.log_level)

    if args.upload and not args.bucket:
        log.error("--upload requires --bucket BUCKET_NAME")
        return 1

    settings = config.BuilderSettings(
        mode="live" if args.live else "offline",
        project_id=args.project or config.BuilderSettings().project_id,
        region_filter=args.regions,
        log_level=args.log_level,
    )
    builder = KnowledgeBuilder(settings, log)
    try:
        builder.build_all(args.only)
        if args.upload:
            builder.upload(args.bucket)
    except Exception:
        log.exception("Build failed")
        return 1
    return 0


if __name__ == "__main__":
    raise SystemExit(main(sys.argv[1:]))
