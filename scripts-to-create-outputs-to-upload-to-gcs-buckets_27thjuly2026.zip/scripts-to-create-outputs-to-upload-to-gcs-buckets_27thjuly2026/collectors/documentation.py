"""Documentation collector.

IMPORTANT DESIGN DECISION
-------------------------
The original spec called for scraping cloud.google.com. We deliberately do NOT
scrape. Doc pages redesign often, break scrapers, and sit in a ToS grey area --
the opposite of "future-proof, low-maintenance".

Instead, doc-derived facts live in version-controlled YAML under knowledge/.
Every entry carries a `source:` URL and an `as_of:` date. A human updates these
when Google ships something new -- which is exactly when you regenerate anyway.

This collector simply loads and lightly validates that overlay. Swapping in a
real scraper later means only changing this one file.
"""
from __future__ import annotations

import logging
from typing import Any

import yaml

import config

log = logging.getLogger("builder.documentation")


class DocumentationCollector:
    def __init__(self, path=config.COMPATIBILITY_YAML) -> None:
        self.path = path

    def load(self) -> dict[str, Any]:
        log.info("Loading curated overlay: %s", self.path)
        with self.path.open(encoding="utf-8") as fh:
            data = yaml.safe_load(fh) or {}
        for key in ("disk_types", "machine_families", "compatibility_rules"):
            data.setdefault(key, [])
        log.info(
            "Overlay: %d disk types, %d families, %d compatibility rules",
            len(data["disk_types"]),
            len(data["machine_families"]),
            len(data["compatibility_rules"]),
        )
        return data
