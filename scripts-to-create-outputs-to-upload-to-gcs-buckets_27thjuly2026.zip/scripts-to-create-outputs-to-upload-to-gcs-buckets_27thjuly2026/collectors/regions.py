"""Region + zone collector. Thin wrapper over ComputeClient that shapes raw
API/snapshot dicts into the fields generators expect."""
from __future__ import annotations

import logging
from typing import Any

from collectors.compute import ComputeClient

log = logging.getLogger("builder.regions")


class RegionCollector:
    def __init__(self, client: ComputeClient) -> None:
        self.client = client

    def collect(self) -> dict[str, list[dict[str, Any]]]:
        regions = self.client.list_regions()
        zones = self.client.list_zones()
        log.info("Collected %d regions, %d zones", len(regions), len(zones))
        return {"regions": regions, "zones": zones}
