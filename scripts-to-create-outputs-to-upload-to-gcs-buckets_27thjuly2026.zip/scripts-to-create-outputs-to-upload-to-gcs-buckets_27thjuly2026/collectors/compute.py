"""Compute API access layer.

This is the *only* module that knows whether we are talking to the real Google
Compute API or reading the offline snapshot. Every other collector calls this
client, so the rest of the codebase is source-agnostic.

Live mode requires ``google-cloud-compute`` and Application Default Credentials.
Offline mode reads ``data/offline_snapshot.json`` and needs nothing.
"""
from __future__ import annotations

import json
import logging
from typing import Any

import config

log = logging.getLogger("builder.compute")


class ComputeClient:
    """Facade over the Compute API with an offline fallback.

    The public methods return plain dicts/lists of primitives so generators
    never depend on Google SDK types.
    """

    def __init__(self, settings: config.BuilderSettings) -> None:
        self.settings = settings
        self._snapshot: dict[str, Any] | None = None
        self._clients: dict[str, Any] = {}

        if settings.mode == "offline":
            self._load_snapshot()
        else:
            self._init_live_clients()

    # ------------------------------------------------------------------ #
    # Offline
    # ------------------------------------------------------------------ #
    def _load_snapshot(self) -> None:
        log.info("Loading offline snapshot: %s", config.OFFLINE_SNAPSHOT_PATH)
        with config.OFFLINE_SNAPSHOT_PATH.open(encoding="utf-8") as fh:
            self._snapshot = json.load(fh)
        log.info(
            "Snapshot loaded (captured %s)",
            self._snapshot.get("_snapshot_meta", {}).get("captured_at", "unknown"),
        )

    # ------------------------------------------------------------------ #
    # Live
    # ------------------------------------------------------------------ #
    def _init_live_clients(self) -> None:
        try:
            from google.cloud import compute_v1  # noqa: PLC0415
        except ImportError as exc:  # pragma: no cover - depends on env
            raise RuntimeError(
                "live mode needs google-cloud-compute. "
                "Install it: pip install google-cloud-compute"
            ) from exc

        log.info("Initialising live Compute API clients for project %s",
                 self.settings.project_id)
        self._clients = {
            "regions": compute_v1.RegionsClient(),
            "zones": compute_v1.ZonesClient(),
            "machine_types": compute_v1.MachineTypesClient(),
            "disk_types": compute_v1.DiskTypesClient(),
        }

    @property
    def data_source_label(self) -> str:
        if self.settings.mode == "offline":
            captured = (self._snapshot or {}).get("_snapshot_meta", {}).get(
                "captured_at", "unknown"
            )
            return f"offline snapshot ({captured})"
        return f"Compute API (project {self.settings.project_id})"

    # ------------------------------------------------------------------ #
    # Public fetch methods -- return primitives
    # ------------------------------------------------------------------ #
    def list_regions(self) -> list[dict[str, Any]]:
        if self.settings.mode == "offline":
            return list(self._snapshot["regions"])  # type: ignore[index]

        from google.cloud import compute_v1  # noqa: PLC0415

        out: list[dict[str, Any]] = []
        req = compute_v1.ListRegionsRequest(project=self.settings.project_id)
        for r in self._clients["regions"].list(request=req):
            out.append(
                {
                    "name": r.name,
                    "description": r.description or None,
                    "status": r.status or "UP",
                    # region.zones is a list of full zone URLs; keep the leaf name
                    "zones": [z.rsplit("/", 1)[-1] for z in r.zones],
                }
            )
        return out

    def list_zones(self) -> list[dict[str, Any]]:
        if self.settings.mode == "offline":
            return list(self._snapshot["zones"])  # type: ignore[index]

        from google.cloud import compute_v1  # noqa: PLC0415

        out: list[dict[str, Any]] = []
        req = compute_v1.ListZonesRequest(project=self.settings.project_id)
        for z in self._clients["zones"].list(request=req):
            out.append(
                {
                    "name": z.name,
                    "region": z.region.rsplit("/", 1)[-1],
                    "status": z.status or "UP",
                }
            )
        return out

    def list_machine_types(self, zones: list[str]) -> list[dict[str, Any]]:
        if self.settings.mode == "offline":
            return list(self._snapshot["machine_types"])  # type: ignore[index]

        from google.cloud import compute_v1  # noqa: PLC0415

        out: list[dict[str, Any]] = []
        for zone in zones:
            req = compute_v1.ListMachineTypesRequest(
                project=self.settings.project_id, zone=zone
            )
            for m in self._clients["machine_types"].list(request=req):
                out.append(
                    {
                        "name": m.name,
                        "guest_cpus": m.guest_cpus,
                        "memory_mb": m.memory_mb,
                        "zone": zone,
                    }
                )
        return out

    def list_disk_types(self, zones: list[str]) -> list[dict[str, Any]]:
        if self.settings.mode == "offline":
            return list(self._snapshot["disk_types"])  # type: ignore[index]

        from google.cloud import compute_v1  # noqa: PLC0415

        seen: dict[str, dict[str, Any]] = {}
        for zone in zones:
            req = compute_v1.ListDiskTypesRequest(
                project=self.settings.project_id, zone=zone
            )
            for d in self._clients["disk_types"].list(request=req):
                # Disk types repeat across zones; dedupe by name.
                seen.setdefault(
                    d.name,
                    {
                        "name": d.name,
                        "description": d.description or None,
                        "valid_disk_size": d.valid_disk_size or None,
                    },
                )
        return list(seen.values())
