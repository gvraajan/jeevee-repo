"""Disk-type collector. The API gives us the disk-type names and size ranges;
the rich attributes (performance ceilings, boot eligibility, regional/multi-
writer support) come from the curated overlay in the DiskGenerator."""
from __future__ import annotations

import logging
from typing import Any

from collectors.compute import ComputeClient

log = logging.getLogger("builder.disks")


class DiskCollector:
    def __init__(self, client: ComputeClient) -> None:
        self.client = client

    def collect(self, zones: list[str]) -> list[dict[str, Any]]:
        raw = self.client.list_disk_types(zones)
        log.info("Collected %d disk types", len(raw))
        return raw
