"""Compatibility collector.

Builds fast lookup indexes from the curated overlay so generators can answer
questions like "which disk types does family c3 support?" without re-scanning.
Kept separate from documentation.py so the *loading* and the *indexing* of
curated knowledge have single responsibilities.
"""
from __future__ import annotations

import logging
from typing import Any

log = logging.getLogger("builder.compatibility")


class CompatibilityIndex:
    def __init__(self, overlay: dict[str, Any]) -> None:
        self._families: dict[str, dict[str, Any]] = {
            f["name"].lower(): f for f in overlay.get("machine_families", [])
        }
        self._disks: dict[str, dict[str, Any]] = {
            d["name"]: d for d in overlay.get("disk_types", [])
        }
        self._rules: list[dict[str, Any]] = overlay.get("compatibility_rules", [])
        log.info(
            "Indexed %d families and %d disk types from overlay",
            len(self._families), len(self._disks),
        )

    def family(self, name: str) -> dict[str, Any] | None:
        return self._families.get(name.lower())

    def all_families(self) -> list[dict[str, Any]]:
        return list(self._families.values())

    def disk(self, name: str) -> dict[str, Any] | None:
        return self._disks.get(name)

    def all_disks(self) -> list[dict[str, Any]]:
        return list(self._disks.values())

    def compatibility_rules(self) -> list[dict[str, Any]]:
        return list(self._rules)
