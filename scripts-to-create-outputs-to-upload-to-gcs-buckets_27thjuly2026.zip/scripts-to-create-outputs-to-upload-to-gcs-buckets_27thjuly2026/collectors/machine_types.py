"""Machine-type collector. Groups raw machine types by family prefix so the
catalog can attach per-family compatibility from the curated overlay."""
from __future__ import annotations

import logging
from typing import Any

from collectors.compute import ComputeClient

log = logging.getLogger("builder.machine_types")


def family_of(machine_type_name: str) -> str:
    """'c3-standard-8' -> 'c3'. The family prefix is everything before the
    first hyphen, which matches Google's naming convention."""
    return machine_type_name.split("-", 1)[0].lower()


class MachineTypeCollector:
    def __init__(self, client: ComputeClient) -> None:
        self.client = client

    def collect(self, zones: list[str]) -> list[dict[str, Any]]:
        raw = self.client.list_machine_types(zones)
        for m in raw:
            m["family"] = family_of(m["name"])
        log.info("Collected %d machine types across %d zones", len(raw), len(zones))
        return raw
