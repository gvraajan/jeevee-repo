"""Questions generator. Loads knowledge/questions.yaml, validates the schema and
dependency conditions, checks ordering, and emits a QuestionsFile."""
from __future__ import annotations

import logging

import yaml

import config
from models import Metadata, Question, QuestionsFile

log = logging.getLogger("builder.gen.questions")


class QuestionsGenerator:
    def __init__(self, path=config.QUESTIONS_YAML) -> None:
        self.path = path

    def build(self, metadata: Metadata) -> QuestionsFile:
        with self.path.open(encoding="utf-8") as fh:
            data = yaml.safe_load(fh) or {}

        questions = [Question(**q) for q in data.get("questions", [])]
        questions.sort(key=lambda q: q.order)

        ids = [q.id for q in questions]
        dupes = {i for i in ids if ids.count(i) > 1}
        if dupes:
            raise ValueError(f"Duplicate question ids: {sorted(dupes)}")

        # Sanity check: every depends_on field should reference a real question.
        maps = {q.maps_to for q in questions}
        for q in questions:
            self._check_depends(q, maps)

        metadata.counts = {"questions": len(questions)}
        log.info("Validated %d questions", len(questions))
        return QuestionsFile(metadata=metadata, questions=questions)

    @staticmethod
    def _check_depends(q: Question, known_fields: set[str]) -> None:
        dep = q.depends_on
        if dep is None:
            return
        fields: list[str] = []

        def walk(node) -> None:
            if hasattr(node, "field") and getattr(node, "field", None):
                fields.append(node.field)
            for attr in ("all_", "any_"):
                sub = getattr(node, attr, None)
                if sub:
                    for child in sub:
                        walk(child)

        walk(dep)
        for f in fields:
            if f not in known_fields:
                log.warning(
                    "Question %r depends on unknown field %r (typo?).", q.id, f
                )
