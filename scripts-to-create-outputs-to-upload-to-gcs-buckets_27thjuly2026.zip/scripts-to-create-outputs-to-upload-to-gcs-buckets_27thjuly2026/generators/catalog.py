"""Catalog generator.

Merges the API-sourced skeleton (regions, zones, machine types, disk-type names)
with the curated overlay (disk performance/eligibility, per-family support,
compatibility rules) into a single validated Catalog model.

The merge is the crux of the whole design: APIs supply *what exists*, the overlay
supplies *what it can do*. Neither source alone is sufficient.
"""
from __future__ import annotations

import logging
from typing import Any

import config
from collectors.compatibility import CompatibilityIndex
from collectors.machine_types import family_of
from models import (
    Catalog, CompatibilityRule, DiskType, MachineFamily, MachineType,
    Metadata, Performance, Region, Zone,
)

log = logging.getLogger("builder.gen.catalog")


class CatalogGenerator:
    def __init__(self, compat: CompatibilityIndex) -> None:
        self.compat = compat

    # ------------------------------------------------------------------ #
    def build(
        self,
        *,
        regions_raw: list[dict[str, Any]],
        zones_raw: list[dict[str, Any]],
        machine_types_raw: list[dict[str, Any]],
        disk_types_raw: list[dict[str, Any]],
        metadata: Metadata,
    ) -> Catalog:
        regions = self._regions(regions_raw)
        zones = self._zones(zones_raw)
        disk_types = self._disk_types(disk_types_raw)
        machine_families = self._machine_families(machine_types_raw)
        machine_types = self._machine_types(machine_types_raw)
        compat_rules = self._compat_rules()

        metadata.counts = {
            "regions": len(regions),
            "zones": len(zones),
            "machine_families": len(machine_families),
            "machine_types": len(machine_types),
            "disk_types": len(disk_types),
            "compatibility_rules": len(compat_rules),
        }

        catalog = Catalog(
            metadata=metadata,
            regions=regions,
            zones=zones,
            machine_families=machine_families,
            machine_types=machine_types,
            disk_types=disk_types,
            compatibility_rules=compat_rules,
        )
        log.info("Catalog assembled: %s", metadata.counts)
        return catalog

    # ------------------------------------------------------------------ #
    @staticmethod
    def _regions(raw: list[dict[str, Any]]) -> list[Region]:
        return [
            Region(
                name=r["name"],
                description=r.get("description"),
                location=r.get("description"),
                status=r.get("status", "UP"),
                zones=r.get("zones", []),
            )
            for r in raw
        ]

    @staticmethod
    def _zones(raw: list[dict[str, Any]]) -> list[Zone]:
        return [
            Zone(name=z["name"], region=z["region"], status=z.get("status", "UP"))
            for z in raw
        ]

    def _disk_types(self, raw: list[dict[str, Any]]) -> list[DiskType]:
        """API gives names + size ranges; overlay gives the rich attributes.
        Overlay wins for enrichment; API presence confirms the disk exists."""
        out: list[DiskType] = []
        api_names = {d["name"] for d in raw}

        for name in sorted(api_names | {d["name"] for d in self.compat.all_disks()}):
            overlay = self.compat.disk(name)
            if not overlay:
                # Disk exists in API but we have no curated knowledge yet.
                log.warning(
                    "Disk %s present in API but missing from overlay; "
                    "emitting minimal entry. Add it to compatibility.yaml.",
                    name,
                )
                out.append(
                    DiskType(
                        name=name,
                        display_name=name,
                        category="hyperdisk" if name.startswith("hyperdisk")
                        else "persistent-disk",
                        description="(no curated metadata yet)",
                    )
                )
                continue

            perf = Performance(**overlay.get("performance", {}))
            out.append(
                DiskType(
                    name=name,
                    display_name=overlay["display_name"],
                    category=overlay["category"],
                    description=overlay.get("description"),
                    is_boot_eligible=overlay.get("is_boot_eligible", False),
                    supports_regional=overlay.get("supports_regional", False),
                    supports_multi_writer=overlay.get("supports_multi_writer", False),
                    min_size_gb=overlay.get("min_size_gb"),
                    max_size_gb=overlay.get("max_size_gb"),
                    performance=perf,
                    restrictions=overlay.get("restrictions", []),
                    source=overlay.get("source"),
                    as_of=overlay.get("as_of"),
                )
            )
        return out

    def _machine_families(self, machine_types_raw: list[dict[str, Any]]) -> list[MachineFamily]:
        """Emit a family entry for every family seen in the API, enriched from
        the overlay. Families in the overlay but absent from the API are still
        emitted (they may exist in regions we didn't scan)."""
        seen_families = {family_of(m["name"]) for m in machine_types_raw}
        overlay_families = {f["name"].lower() for f in self.compat.all_families()}

        out: list[MachineFamily] = []
        for fam in sorted(seen_families | overlay_families):
            overlay = self.compat.family(fam)
            if not overlay:
                log.warning(
                    "Machine family %s seen in API but missing from overlay; "
                    "disk support unknown. Add it to compatibility.yaml.", fam,
                )
                out.append(
                    MachineFamily(
                        name=fam,
                        display_name=fam.upper(),
                        category="general-purpose",
                        description="(no curated compatibility yet)",
                        notes=["Disk support not yet curated."],
                    )
                )
                continue
            out.append(
                MachineFamily(
                    name=overlay["name"].lower(),
                    display_name=overlay["display_name"],
                    category=overlay["category"],
                    description=overlay.get("description"),
                    supported_disk_types=overlay.get("supported_disk_types", []),
                    hyperdisk_support=overlay.get("hyperdisk_support", []),
                    boot_disk_types=overlay.get("boot_disk_types", []),
                    max_disks=overlay.get("max_disks"),
                    notes=overlay.get("notes", []),
                    source=overlay.get("source"),
                    as_of=overlay.get("as_of"),
                )
            )
        return out

    @staticmethod
    def _machine_types(raw: list[dict[str, Any]]) -> list[MachineType]:
        """Collapse the same machine type appearing in multiple zones into one
        entry with an aggregated zone list."""
        by_name: dict[str, MachineType] = {}
        for m in raw:
            name = m["name"]
            zone = m.get("zone")
            if name in by_name:
                if zone and zone not in by_name[name].zones:
                    by_name[name].zones.append(zone)
                continue
            by_name[name] = MachineType(
                name=name,
                family=family_of(name),
                guest_cpus=m.get("guest_cpus"),
                memory_mb=m.get("memory_mb"),
                zones=[zone] if zone else [],
            )
        return list(by_name.values())

    def _compat_rules(self) -> list[CompatibilityRule]:
        return [
            CompatibilityRule(
                id=r["id"],
                statement=r["statement"],
                applies_to=r.get("applies_to", {}),
                source=r.get("source"),
                as_of=r.get("as_of"),
            )
            for r in self.compat.compatibility_rules()
        ]
