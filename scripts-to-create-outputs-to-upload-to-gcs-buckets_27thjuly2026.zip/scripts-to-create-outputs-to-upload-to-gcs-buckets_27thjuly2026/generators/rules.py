"""Rules generator. Loads knowledge/rules.yaml, validates every rule through the
Pydantic schema (so a malformed condition fails the build, not Cloud Run), and
emits a RulesFile. No rule logic lives here -- only load + validate."""
from __future__ import annotations

import logging

import yaml

import config
from models import Metadata, Recommendation, RulesFile, Rule

log = logging.getLogger("builder.gen.rules")


class RulesGenerator:
    def __init__(self, path=config.RULES_YAML) -> None:
        self.path = path

    def build(self, metadata: Metadata) -> RulesFile:
        with self.path.open(encoding="utf-8") as fh:
            data = yaml.safe_load(fh) or {}

        default = Recommendation(**data["default_recommendation"])
        rules = [Rule(**r) for r in data.get("rules", [])]

        # Guard against duplicate rule IDs -- a common curation mistake.
        ids = [r.id for r in rules]
        dupes = {i for i in ids if ids.count(i) > 1}
        if dupes:
            raise ValueError(f"Duplicate rule ids in rules.yaml: {sorted(dupes)}")

        metadata.counts = {"rules": len(rules)}
        log.info("Validated %d rules (priorities %s)",
                 len(rules), sorted({r.priority for r in rules}, reverse=True))
        return RulesFile(metadata=metadata, default_recommendation=default, rules=rules)
